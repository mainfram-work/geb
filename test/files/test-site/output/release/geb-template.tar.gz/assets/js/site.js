
// use jquery to log a message to the console once the page loads
$(document).ready(function() {
    console.log('site.js loaded');
}

<%= partial: assets/js/_library.js %>